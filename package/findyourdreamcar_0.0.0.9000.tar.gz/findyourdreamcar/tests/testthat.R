library(testthat)
library(findyourdreamcar)

test_check("findyourdreamcar")
