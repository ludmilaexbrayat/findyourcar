## ----cars, warning=F-----------------------------------------------------
#devtools::install_github("ludmilaexbrayat/findyourcar/package/findyourdreamcar")

library(findyourdreamcar)

# By loading the library, the cardata dataset is loaded - feel free to explore it!

head(cardata, 1)

# Launch the Shiny app - feel free to interact with it!

# run_app()

